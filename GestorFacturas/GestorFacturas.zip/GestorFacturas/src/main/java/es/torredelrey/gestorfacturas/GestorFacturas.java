/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package es.torredelrey.gestorfacturas;

import es.torredelrey.gestorfacturas.vista.LogIn;

/**
 *
 * @author Usuario
 */
public class GestorFacturas {

    public static void main(String[] args) {
        LogIn lg = new LogIn();
        lg.show(true);
    }
}
